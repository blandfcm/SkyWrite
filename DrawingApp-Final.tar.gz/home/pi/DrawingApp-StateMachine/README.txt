Drawing App - base functionality
Last Edit: [5/2/17]
	shapes: dot, line, square
	edit shape: move (WASD), rotate, place, delete
	clear_canvas 

to run:
	sudo python drawing_app.py

to do:
	comment code
	implement other features

'drawing_app.py' is named 'drawing_app_plz_work.py' in PyCharm Project

